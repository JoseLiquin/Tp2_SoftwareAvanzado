package controller;

import service.TransaccionService;

@RestController
@RequestMapping("/api/v1/transacciones/transferir")
@RequiredArgsConstructor
public class TransaccionController {
   private final TransaccionService transaccionService;
   
   @GetMapping({id})
   public ResponseEntity<TransaccionDto>transferir(@Valid @RequestBody TransferenciaRequestDto requestDto) {
       TransferenciaResponseDto response = transaccionService.transferir(
               requestDto.getCbuOrigen(),
               requestDto.getCbuDestino(),
               requestDto.getMonto()
       );
       return ResponseEntity.ok(response);
}
}
