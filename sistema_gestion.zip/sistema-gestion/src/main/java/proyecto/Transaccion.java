package proyecto;


import java.time.LocalTime;
import java.util.Date;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="transacciones")
public class Transaccion {
	 @Id
	    @GeneratedValue(strategy = GenerationType.UUID)
	    private UUID nroComprobante;

	    @Column(nullable = false)
	    private Date fecha;

	    @Column(nullable = false)
	    private LocalTime hora;

	    @Column(name = "monto", nullable = false, precision = 15, scale = 2)
	    private double monto;

	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false)
	    private String tipo;

	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false)
	    private String estadoTransaccion;

	    @ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "cuenta_cbu", nullable = false)

// Constructores
public Transaccion() {
}

public Transaccion(UUID nroComprobante, Date fecha, LocalTime hora, double monto, String tipo, String estadoTransaccion, CuentaFinanciera cuenta) {
    this.nroComprobante = nroComprobante;
    this.fecha = fecha;
    this.hora = hora;
    this.monto = monto;
    this.tipo = tipo;
    this.estadoTransaccion = estadoTransaccion;
    this.cuenta = cuenta;
}

// Getters y Setters

public UUID getNroComprobante() {
    return nroComprobante;
}

public void setNroComprobante(UUID nroComprobante) {
    this.nroComprobante = nroComprobante;
}

public Date getFecha() {
    return fecha;
}

public void setFecha(Date fecha) {
    this.fecha = fecha;
}

public LocalTime getHora() {
    return hora;
}

public void setHora(LocalTime hora) {
    this.hora = hora;
}

public double getMonto() {
    return monto;
}

public void setMonto(double monto) {
    this.monto = monto;
}

public String getTipo() {
    return tipo;
}

public void setTipo(String tipo) {
    this.tipo = tipo;
}

public String getEstadoTransaccion() {
    return estadoTransaccion;
}

public void setEstadoTransaccion(String estadoTransaccion) {
    this.estadoTransaccion = estadoTransaccion;
}

public CuentaFinanciera getCuenta() {
    return cuenta;
}

public void setCuenta(CuentaFinanciera cuenta) {
    this.cuenta = cuenta;
}


public enum tipo{
	DEPOSITO,
	EXTRACCION,
	TRANSFERENCIA_ENVIADA,
	TRANSFERENCIA_RECIBIDA
}
public enum estado_transaccion{
	PENDIENTE,
	COMPLETADA,
	RECHAZADA,
	REVERTIDA
}
}
