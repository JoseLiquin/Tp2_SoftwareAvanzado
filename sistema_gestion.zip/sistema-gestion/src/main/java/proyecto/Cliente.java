package proyecto;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity

@Table(name="clientes")
public class Cliente  {
	@Column(name= "nombre",nullable=false,length=20)
	 private String nombre;
	@Column(name= "apellido",nullable=false,length=20)
	  private String apellido;
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	   private UUID id;
	@Column(name="cuil",nullable=false,unique=true,length=12)
	    private String cuil;
	@Column(name= "email",nullable=false,length=20)
	    private String email;
	@Column(name= "telefono",nullable=false,length=10)
	    private long telefono;
	@Column(name= "direccion",nullable=false,length=20)
	    private String direccion;
	private List<Cliente> titular;  //bsucar como represantar en la base de datos 
   @OneToMany(fetch= FetchType.LAZY ,cascade = CascadeType.ALL,orphanRemoval=true)
   @JoinColumn(name="cliente_cuil")
   private List<CuentaFinanciera> cuentas;
   //cambiar constructores por builder
	    private  Cliente(String nombre, String cuil, String email, Long telefono, String direccion, String apellido) {
	        this.nombre = nombre;
	        this.cuil =cuil;
	        this.email =email;
	        this.telefono = telefono;
	        this.direccion =direccion;
	    }
	    public String getNombre() {
	        return nombre;
	    }

	   

	    public String getApellido(){
	        return apellido;
	    }
       
	   

	    public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		
		public String getCuil() {
	        return cuil;
	    }

	    public void setCuil(String cuil) {
	        this.cuil = cuil;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public Long getTelefono() {
	        return telefono;
	    }

	    public void setTelefono(Long telefono) {
	        this.telefono = telefono;
	    }

	    public String getDireccion() {
	        return direccion;
	    }

	    public void setDireccion(String direccion) {
	        this.direccion = direccion;
	    }

	    public List<Cliente> getTitular() {
	        return titular;
	    }

	    public void setTitular(List<Cliente> titularidad) {
	        this.titular = titular;
	    }

	    public List<CuentaFinanciera> getCuentas() {
	        return cuentas;
	    }

	    public void setCuentas(List<CuentaFinanciera> cuentas) {
	        this.cuentas = cuentas;
	    }
    
     
	    public void registrarCliente(String nombre) {
	    	System.out.println("se registro el cliente " + nombre);
	    }
	    @Override
	    public String toString() {
	        return "Cliente{" +
	                "cuil=" + cuil +
	                ", nombre='" + nombre + '\'' +
	                ", apellido='" + apellido + '\'' +
	      //          ", cantidadCuentas=" + (cuentas != null ? cuentas.size() : 0) +
	                '}';
}
