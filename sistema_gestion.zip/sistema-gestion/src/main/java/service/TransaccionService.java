package service;

import dto.TransferenciaResponseDto;

public interface TransaccionService {
	 TransferenciaResponseDto transferir(String cbuOrigen, String cbuDestino, Double monto);
	
}
