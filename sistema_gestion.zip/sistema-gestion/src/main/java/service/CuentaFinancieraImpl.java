package service;

import com.example.tp2.dto.CuentaRequestDto;

import dto.CuentaResponseDto;
import dto.CuentaRequestDto;
@Service
@RequiredArgsConstructor
@Slf4j
public class CuentaFinancieraImpl implements CuentaFinanciera{

	    private final CuentaFinancieraRepository cuentaRepository;

	    @Override
	    public CuentaResponseDto crearCuenta(CuentaRequestDto requestDto) {
	    	 CuentaFinanciera cuentaGuardada = cuentaRepository.save(cuenta);
	    	 return mapearAResponseDto(cuentaGuardada);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public CuentaResponseDto obtenerPorCbu(String cbu) {
	        CuentaFinanciera cuenta= cuentaRepository.findByCbu(cbu)
	                .orElseThrow(() -> new RecursoNoEncontradoException("No se encuentra una cuenta con ese cbu"));
	        return mapToResponseDto(cuenta);
	        
	    }
	    
	    
	    private CuentaResponseDto mapToResponseDto(CuentaFinancieria cuenta) {
	    	// String nombreTitular = cuenta.getTitulares().isEmpty()
	                 ? null
	                 : cuenta.getTitulares().get(0).getNombre();// ver si es importante

	         return CuentaResponseDto.builder()
	                 .cbu(cuenta.getCbu())
	                 .alias(cuenta.getAlias())
	                 .saldo(cuenta.getSaldo())
	                 .titular(nombreTitular)
	                 .build();
	    }
	}

