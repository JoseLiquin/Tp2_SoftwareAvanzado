package service;

import dto.CuentaRequestDto;
import dto.CuentaResponseDto;

public interface CuentaFinanciera {
	
	    CuentaResponseDto crearCuenta(CuentaRequestDto requestDto);

	    CuentaResponseDto obtenerPorCbu(String cbu);
	}

