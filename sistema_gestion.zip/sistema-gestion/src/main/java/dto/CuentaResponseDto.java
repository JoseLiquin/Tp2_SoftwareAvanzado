package dto;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class CuentaResponseDto {
	
	    private String cbu;
	    private String alias;
	    private Double saldo;
	    private EstadoCuenta estado;
	}

