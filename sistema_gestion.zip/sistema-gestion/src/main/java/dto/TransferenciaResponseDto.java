package dto;

	

	import lombok.AllArgsConstructor;
	import lombok.Builder;
	import lombok.Data;
	import lombok.NoArgsConstructor;

	import java.time.LocalDate;
	import java.time.LocalTime;
	import java.util.UUID;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public class TransferenciaResponseDto {
	    private UUID nroComprobante;
	    private String cbuOrigen;
	    private String cbuDestino;
	    private Double monto;
	    private EstadoTransaccion estadoTransaccion;
	    private Date fecha;
	    private LocalTime hora;
			}

