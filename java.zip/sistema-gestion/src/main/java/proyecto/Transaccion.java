package proyecto;


import java.time.LocalTime;
import java.util.Date;

import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class Transaccion {
private Date fecha;
private LocalTime hora;
private float monto;
private String tipo;
private String estado_transaccion;
@ManyToOne(fetch=FetchType.LAZY)
@JoinColumn(name="cuenta_cbu",nullable=false)
private CuentaFinanciera cuenta;
public Transaccion(Date fecha, LocalTime hora, float monto, String tipo, String estado_transaccion) {
	super();
	this.fecha = fecha;
	this.hora = hora;
	this.monto = monto;
	this.tipo = tipo;
	this.estado_transaccion = estado_transaccion;
}


}
