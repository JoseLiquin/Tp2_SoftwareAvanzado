package proyecto;

import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;

@Entity
@Table(name="cliente")
@PrimaryKeyJoinColumn(name="CBU")
public class CuentaCorriente extends CuentaFinanciera{
private float margen;
private float costo_comision;
public CuentaCorriente(float margen, float costo_comision) {
	super();
	this.margen = margen;
	this.costo_comision = costo_comision;
}

}
