package proyecto;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
@Entity
@Table(name="cuentas_financieras")
@Inheritance(strategy=InheritanceType.JOINED)
public abstract class CuentaFinanciera {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long CBU;
	    private String alias;
	    protected double saldo;
	    private String estado;
   @ManyToOne(fetch =FetchType.LAZY)
   @JoinColumn(name="cliente_cuil", insertable=false,updatable=false)
   private Cliente cliente;
   @OneToMany(mappedBy= "cuenta", fetch =FetchType.LAZY,cascade =CascadeType.ALL)
   private List<Transaccion> transacciones;
   
	    public CuentaFinanciera() {

	    }

	    public long getCBU() {
	        return CBU;
	    }

	    public void setCBU(long CBU) {
	        this.CBU = CBU;
	    }

	    public String getAlias() {
	        return alias;
	    }

	    public void setAlias(String alias) {
	        this.alias = alias;
	    }

	    public double getSaldo() {
	        return saldo;
	    }

	    public void setSaldo(double saldo) {
	        this.saldo = saldo;
	    }

	    public String getEstado() {
	        return estado;
	    }

	    public void setEstado(String estado) {
	        this.estado = estado;
	    }

	    
	    public void depositar(double saldoActual){

	        saldoActual =+ saldo;
	    }
	    public void extraer(double extraccion){

	        if(saldo < extraccion){
	            System.out.println("Saldo insufiente para extracion");
	        }else {
	            saldo = -extraccion;
	        }

	    }

	    public void enviarTransferencia(double transferir, long cbu){
	        if(transferir < saldo){
	            System.out.println("Saldo insuficiente");
	        }
	        saldo =- transferir;
	        System.out.println("Tranferencia exitosa a: "+ saldo);
	    }
	
}
