package proyecto;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
@Table(name="cliente")
public class Cliente {
	 private String nombre;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int cuil;
	    private String email;
	    private int telefono;
	    private String direccion;
   @OneToMany(fetch= FetchType.LAZY ,cascade = CascadeType.ALL)
   @JoinColumn(name="cliente_cuil")
   private List<CuentaFinanciera> cuentas;
   
	    public Cliente(String nombre, int cuil, String email, int telefono, String direccion) {
	        this.nombre = nombre;
	        this.cuil = cuil;
	        this.email = email;
	        this.telefono = telefono;
	        this.direccion = direccion;
	    }
	    public void registrarCliente(String nombre) {
	    	System.out.println("se registro el cliente " + nombre);
	    }
}
