package proyecto;

import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
@Entity
@Table(name="cliente")
@PrimaryKeyJoinColumn(name="CBU")

public class CajadeAhorro extends CuentaFinanciera {
private int cupo_limite;
private float interes_anual;

public CajadeAhorro(int cupo_limite, float interes_anual) {
	super();
	this.cupo_limite = cupo_limite;
	this.interes_anual = interes_anual;
}

}
